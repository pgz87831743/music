package jx.pgz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class WorkOrderStarter {

    public static void main(String[] args) {
        SpringApplication.run(WorkOrderStarter.class);
    }
}
