package jx.pgz.dao.sys.mapper;

import jx.pgz.dao.sys.entity.SysFile;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
public interface SysFileMapper extends BaseMapper<SysFile> {

}
