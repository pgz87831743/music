package jx.pgz.dao.sys.service;

import jx.pgz.dao.sys.entity.Music;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 
 * @since 2023-02-17
 */
public interface MusicService extends IService<Music> {

}
