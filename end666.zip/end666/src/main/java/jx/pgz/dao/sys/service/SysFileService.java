package jx.pgz.dao.sys.service;

import jx.pgz.dao.sys.entity.SysFile;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
public interface SysFileService extends IService<SysFile> {

}
