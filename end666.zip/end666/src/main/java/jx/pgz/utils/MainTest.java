package jx.pgz.utils;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;

public class MainTest {

    public static void main(String[] args) {


        System.out.println(new Date().getTime());


    }
}
