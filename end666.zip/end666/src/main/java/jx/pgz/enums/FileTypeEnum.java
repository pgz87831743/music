package jx.pgz.enums;

public enum FileTypeEnum {
    FILE("文件"),
    MUSIC("文件");

    FileTypeEnum(String type) {
    }
}
